sudo apt-get update

sudo apt-get upgrade -y

git clone https://github.com/HanZawNyine/DeveloperForEssentialToolInstaller

cd DeveloperForEssentialToolInstaller

python3 Agga.py
