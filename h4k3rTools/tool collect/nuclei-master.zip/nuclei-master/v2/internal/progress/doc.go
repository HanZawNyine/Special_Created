// Package progress implements progress display mechanism with very
// simple command line statistics printing on runtime.
package progress
