---
name: Issue report
about: Create a report to help us improve
title: "[issue]"
labels: ''
assignees: ''

---

**Describe the bug**
A clear and concise description of what the bug is.

**Nuclei version**
Please share the version of the nuclei you are running with `nuclei -version` 


**Screenshot of the error or bug**
please add the screenshot showing bug or issue you are facing.
