<?php
$red="\033[0;31m";
$blue="\033[0;34m";
$green="\033[0;32m";
$yellow="\033[0;33m";
$cyan="\033[0;36m";
$purple="\033[0;35m";
$token =file_get_contents("token.txt");
$url = file_get_contents("https://graph.facebook.com/me?access_token=".$token);
  $decode = json_decode($url);
echo $green."
{}{}{}{}{}{}{}{}{} Welcome My User{}{}{}{}{}{}{}{}
{}{}{}     UserName:".$decode->name."              {}{}
{}{}{}     Id:".$decode->id."                 {}{}
{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}\n";
   
?>
