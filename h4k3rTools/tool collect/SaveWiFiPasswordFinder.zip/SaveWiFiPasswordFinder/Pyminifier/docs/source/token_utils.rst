:mod:`token_utils.py` - A collection of token-related functions
===============================================================

.. moduleauthor:: Dan McDougall (daniel.mcdougall@liftoffsoftware.com)

.. automodule:: pyminifier.token_utils
    :members:
    :private-members:
