:mod:`analyze.py` - For analyzing Python code
=============================================

.. moduleauthor:: Dan McDougall (daniel.mcdougall@liftoffsoftware.com)

.. automodule:: pyminifier.analyze
    :members:
    :private-members:
