:mod:`compression.py` - For compressing Python code
===================================================

.. moduleauthor:: Dan McDougall (daniel.mcdougall@liftoffsoftware.com)

.. automodule:: pyminifier.compression
    :members:
    :private-members:
