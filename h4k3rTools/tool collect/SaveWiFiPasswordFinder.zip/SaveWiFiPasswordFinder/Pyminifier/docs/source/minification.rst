:mod:`minification.py` - For minifying Python code
===================================================

.. moduleauthor:: Dan McDougall (daniel.mcdougall@liftoffsoftware.com)

.. automodule:: pyminifier.minification
    :members:
    :private-members:
