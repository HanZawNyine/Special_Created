:mod:`pyminifier.py` - The main module for minifying, obfuscating, and compressing Python code
==============================================================================================

.. moduleauthor:: Dan McDougall (daniel.mcdougall@liftoffsoftware.com)

.. automodule:: pyminifier
    :members:
    :private-members:
