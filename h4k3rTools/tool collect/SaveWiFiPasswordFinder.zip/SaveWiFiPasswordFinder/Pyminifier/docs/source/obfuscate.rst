:mod:`obfuscate.py` - For obfuscating Python code
=================================================

.. moduleauthor:: Dan McDougall (daniel.mcdougall@liftoffsoftware.com)

.. automodule:: pyminifier.obfuscate
    :members:
    :private-members:
