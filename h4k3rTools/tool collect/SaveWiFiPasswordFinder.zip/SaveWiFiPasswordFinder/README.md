# SaveWiFiPasswordFinder

    Change Your Gmail & Password
    
# Screenshot

<img src="https://github.com/AungThuMyint/SaveWiFiPasswordFinder/blob/main/SaveWiFiPasswordFinder.jpg">

# Installation Pyminifier

    cd Pyminifier
    
    python3 setup.py build
    
    python3 setup.py install
    
# Run Pyminifier

    pyminifier --help
    
    pyminifier <options> <your-python-file>
