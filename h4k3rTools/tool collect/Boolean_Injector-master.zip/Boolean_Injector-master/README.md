# Boolean_Injector

Good Luck:v

# Installation

	git clone https://github.com/S03HT3T/Boolean_Injector.git
	cd Boolean_Injector
	chmod +x boolean_injector.py
	
# Usage

	python3 boolean_injector.py
	
	
![alt text](https://i.imgur.com/Sk0qU2d.jpg)


![alt text](https://i.imgur.com/OOQqLGx.jpg)
